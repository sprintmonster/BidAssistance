import { Home } from "./Home";

export function HomePage() {
  return <Home />;
}

/** 과거 App.tsx 호환(alias) */
export const MainPage = HomePage;
